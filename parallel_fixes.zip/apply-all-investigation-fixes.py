#!/usr/bin/env python3
# ============================================================================
# Klasivo — ALL DAYS Master Script (Production Investigation Fixes)
# ============================================================================
# Runs all 4 days of fixes from the Production Investigation report:
#
#   Day 1 (Today):    Provider sync, notifications, exam creation
#   Day 2 (Tomorrow): RBAC init, mustChangePassword, Excel password, dashboard flicker
#   Day 3 (Day 3):    registerOwner CF, registerParent CF, messaging fix, rules
#   Day 4 (Day 4):    Client migration, rules cleanup, navigation, violations
#
# Prerequisites:
#   - Sprint 1 security patches (C-01 through C-18) already deployed
#   - Clean git working tree
#   - Python 3.7+
#
# Usage:
#   cd C:\Users\Strik\Klasivo
#   python apply-all-investigation-fixes.py
# ============================================================================

import os, sys, subprocess, argparse
from pathlib import Path
from datetime import datetime

if not Path("firestore.rules").exists():
    print("ERROR: Run from Klasivo repo root."); sys.exit(1)

parser = argparse.ArgumentParser(description="Apply ALL Klasivo production investigation fixes (Days 1-4)")
parser.add_argument("--no-push", action="store_true")
parser.add_argument("--no-build", action="store_true")
parser.add_argument("--force", action="store_true")
args = parser.parse_args()

print("=" * 70)
print("KLASIVO PRODUCTION INVESTIGATION — ALL DAYS MASTER SCRIPT")
print("=" * 70)
print(f"Working directory: {Path.cwd()}")

try:
    current_commit = subprocess.check_output(["git","rev-parse","--short","HEAD"],text=True).strip()
    print(f"Current commit: {current_commit}")
except: sys.exit(1)
print()

print("This script applies ALL 4 days of fixes from the Production Investigation.")
print()
print("  Day 1: Provider sync + notifications + exam creation (60 min)")
print("  Day 2: RBAC init + mustChangePassword + Excel password + dashboard flicker (60 min)")
print("  Day 3: registerOwner/Parent CFs + messaging fix + rules (2-3 hours)")
print("  Day 4: Client migration + rules cleanup + navigation (1-2 hours)")
print()
print("Total estimated time: 4-6 hours")
print()

response = input("Proceed with all 4 days? (yes/no): ").strip().lower()
if response != "yes":
    print("Aborted. Run individual day scripts instead.")
    sys.exit(0)
print()

# Check for uncommitted changes
status = subprocess.check_output(["git","status","--porcelain"],text=True).strip()
if status and not args.force:
    print("ERROR: Working tree has uncommitted changes.")
    print("Run: git stash  OR  re-run with --force")
    sys.exit(1)

# Create master backup
timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
master_backup = f"backup-before-all-investigation-{timestamp}"
subprocess.run(["git","branch",master_backup],capture_output=True)
print(f"Master backup branch: {master_backup}")
print(f"To rollback everything: git reset --hard {master_backup}")
print()

# Find the scripts
script_locations = [
    Path("/home/z/my-project/download/patches"),
    Path("."),
    Path("patches"),
]

day_scripts = {
    "Day 1": "apply-today-fixes.py",
    "Day 2": "apply-day2-tomorrow.py",
    "Day 3": "apply-day3-registration-messaging.py",
    "Day 4": "apply-day4-cleanup.py",
}

found_scripts = {}
for day_name, script_name in day_scripts.items():
    for loc in script_locations:
        script_path = loc / script_name
        if script_path.exists():
            found_scripts[day_name] = script_path
            break

if len(found_scripts) != 4:
    print("ERROR: Could not find all 4 day scripts.")
    print(f"Found: {list(found_scripts.keys())}")
    print(f"Missing: {[d for d in day_scripts if d not in found_scripts]}")
    sys.exit(1)

print("=" * 70)
print("APPLYING ALL 4 DAYS")
print("=" * 70)
print()

failed_days = []
for day_name, script_path in found_scripts.items():
    print(f"--- {day_name} ({script_path.name}) ---")

    cmd = ["python", str(script_path), "--no-push"]
    if args.no_build:
        cmd.append("--no-build")
    if args.force:
        cmd.append("--force")

    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"\n[ERROR] {day_name} failed!")
        failed_days.append(day_name)
        resp = input(f"\n{day_name} failed. Continue to next day? (y/n): ").strip().lower()
        if resp != "y":
            print(f"\n[ABORT] Stopped at {day_name}.")
            print(f"Rollback: git reset --hard {master_backup}")
            sys.exit(1)
    print()

# ============================================================================
# Final summary
# ============================================================================
print("=" * 70)
print("ALL DAYS COMPLETE")
print("=" * 70)
print()

if failed_days:
    print(f"[!] Failed days: {failed_days}")
    print("    Review output above and fix manually.")
else:
    print("[OK] All 4 days applied successfully!")
print()

print("Commits created:")
try:
    result = subprocess.run(["git","log","--oneline","-5"],capture_output=True,text=True,check=True)
    print(result.stdout)
except: pass

# Final build check
if not args.no_build:
    print("=" * 70)
    print("FINAL BUILD CHECK")
    print("=" * 70)
    os.chdir("functions")
    try:
        result = subprocess.run(["npm","run","build"],shell=True)
        if result.returncode != 0:
            print("\n[ERROR] Build failed! Fix before deploying.")
            os.chdir("..")
            sys.exit(1)
        print("\n  [OK] Build succeeded")
    finally:
        os.chdir("..")
    print()

# Push
if args.no_push:
    print("[!] Skipping push (--no-push)")
    print("    git push origin main  (when ready)")
else:
    print("=" * 70)
    print("PUSHING ALL COMMITS TO GITHUB")
    print("=" * 70)
    resp = input("\nPush all commits to origin? (y/n): ").strip().lower()
    if resp == "y":
        result = subprocess.run(["git","push","origin","main"])
        if result.returncode != 0:
            print("\n[ERROR] Push failed")
            print("Try: git pull --rebase origin main && git push origin main")
            sys.exit(1)
        print("\n  [OK] All commits pushed!")
        new_commit = subprocess.check_output(["git","rev-parse","--short","HEAD"],text=True).strip()
        print(f"  Latest: https://github.com/Strike87/Klasivo/commit/{new_commit}")
    else:
        print("[!] Push skipped. Run: git push origin main")

# ============================================================================
# Post-deploy instructions
# ============================================================================
print()
print("=" * 70)
print("DEPLOY + VERIFICATION INSTRUCTIONS")
print("=" * 70)
print()
print("1. Deploy to Firebase:")
print("   firebase deploy --only functions,firestore:rules,firestore:indexes")
print()
print("2. Run verification checklist:")
print()
print("   AUTH:")
print("   [ ] Owner registers (via CF) → org created → claims set → can navigate")
print("   [ ] Teacher registers with invite code → claims set")
print("   [ ] Student logs in → redirected to /change-password → changes password")
print("   [ ] Parent registers (via CF) → user doc created")
print("   [ ] /change-password route works → navigates to dashboard after")
print()
print("   CORE FEATURES:")
print("   [ ] Academic Structure shows stages + classes (not '0 Classes')")
print("   [ ] Dashboard metrics load and persist on refresh/navigation")
print("   [ ] Exam creation succeeds (no permission-denied)")
print("   [ ] Notifications page loads (no permission-denied)")
print("   [ ] Messaging: create conversation → send message → recipient reads")
print()
print("   SECURITY:")
print("   [ ] App Check enforced (curl rejected)")
print("   [ ] Observers read-only")
print("   [ ] Orgs can't be destroyed via deleteStudent")
print("   [ ] Claims sync works (role change propagates without re-login)")
print()
print("3. Manual work still needed (after verification):")
print("   - Update screens to call *ViaCF methods (owner_register_screen, etc.)")
print("   - Convert ShellRoute to StatefulShellRoute.indexedStack if tab flicker persists")
print("   - Delete dead duplicate auth_provider files")
print("   - syncClaims.ts: add roleVersion increment")
print()
print("Rollback everything:")
print(f"  git reset --hard {master_backup}")
print("  git push origin main --force")
print("  firebase deploy --only functions,firestore:rules,firestore:indexes")
