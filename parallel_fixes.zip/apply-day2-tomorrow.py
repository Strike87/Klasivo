#!/usr/bin/env python3
# ============================================================================
# Klasivo Day 2 — RBAC Init + mustChangePassword + Excel Password + Claims
# ============================================================================
# Fixes from Production Investigation report (tomorrow's work):
#   P0-3: Owners/teachers never get custom claims → wire up rbacInitProvider
#   P0-6: mustChangePassword never set on student creation
#   P0-7: Excel import uses sentinel password 'CHANGED_USE_HASHER'
#   Issue 5: rbacInitProvider is dead code — never called
#   syncClaims doesn't increment roleVersion
#
# Usage:
#   cd C:\Users\Strik\Klasivo
#   python apply-day2-tomorrow.py
# ============================================================================

import os, sys, re, subprocess, argparse
from pathlib import Path
from datetime import datetime

if not Path("firestore.rules").exists():
    print("ERROR: Run from Klasivo repo root."); sys.exit(1)

parser = argparse.ArgumentParser(description="Apply Klasivo Day 2 fixes")
parser.add_argument("--no-push", action="store_true")
parser.add_argument("--no-build", action="store_true")
parser.add_argument("--force", action="store_true")
args = parser.parse_args()

print("=" * 70); print("KLASIVO DAY 2 — RBAC + Password + Claims"); print("=" * 70)
print(f"Working directory: {Path.cwd()}")

try:
    print(f"Current commit: {subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()}")
except: sys.exit(1)
print()

status = subprocess.check_output(["git","status","--porcelain"],text=True).strip()
if status and not args.force:
    print("ERROR: Working tree has uncommitted changes. Use --force or git stash"); sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = f"backup-before-day2-{timestamp}"
subprocess.run(["git","branch",backup],capture_output=True)
print(f"Backup: {backup}\n")

fixes = []

# ============================================================================
# P0-6: Add mustChangePassword to createStudent.ts (10 min)
# ============================================================================
print("--- P0-6: Add mustChangePassword to createStudent.ts ---")

cs_path = Path("functions/src/functions/createStudent.ts")
if cs_path.exists():
    content = cs_path.read_text(encoding="utf-8")

    # Find the .set() call that creates the user doc and add mustChangePassword
    old_set = "'authProvider': 'student_code',"
    new_set = "'authProvider': 'student_code',\n            'mustChangePassword': true,  // P0-6: Force password change on first login"

    if old_set in content and "mustChangePassword" not in content:
        content = content.replace(old_set, new_set)
        cs_path.write_text(content, encoding="utf-8")
        print("  [OK] Added mustChangePassword: true to createStudent.ts")
        fixes.append("P0-6: mustChangePassword")
    elif "mustChangePassword" in content:
        print("  [OK] Already present (skipping)")
    else:
        print("  [!] Pattern not found — add manually after 'authProvider': 'student_code',")
print()

# ============================================================================
# P0-7: Fix Excel import sentinel password (15 min)
# ============================================================================
print("--- P0-7: Fix Excel import sentinel password ---")

for file_str in ["lib/core/services/student_service.dart", "lib/core/services/excel_import_service.dart"]:
    fp = Path(file_str)
    if not fp.exists():
        print(f"  [SKIP] {file_str} not found"); continue

    content = fp.read_text(encoding="utf-8")

    # Replace fallback to defaultStudentPassword with generateTemporaryPassword
    old_fallback = "AppConstants.defaultStudentPassword"
    new_fallback = "PasswordHasher.instance.generateTemporaryPassword()  // P0-7: was defaultStudentPassword"

    if old_fallback in content:
        content = content.replace(old_fallback, new_fallback)

        # Add import if not present
        if "password_hasher" not in content:
            lines = content.split("\n")
            last_import = -1
            for i, line in enumerate(lines):
                if line.startswith("import "): last_import = i
            if last_import >= 0:
                lines.insert(last_import + 1, "import 'package:klasivo/core/services/password_hasher.dart';")
                content = "\n".join(lines)

        fp.write_text(content, encoding="utf-8")
        print(f"  [OK] {file_str}: replaced sentinel with generateTemporaryPassword()")
        fixes.append("P0-7: Excel password")
    else:
        print(f"  [SKIP] {file_str}: no defaultStudentPassword reference")
print()

# ============================================================================
# Issue 5: Wire up rbacInitProvider (30 min)
# ============================================================================
print("--- Issue 5: Wire up rbacInitProvider on login ---")

auth_path = Path("lib/providers/auth_provider.dart")
if auth_path.exists():
    content = auth_path.read_text(encoding="utf-8")

    # After each save*AuthData function's Hive writes, add rbacInitProvider call
    # Look for patterns like "box.put('isLoggedIn', true);" and add after
    patterns_to_find = [
        ("box.put('isLoggedIn', true);", "box.put('isLoggedIn', true);\n    ref.read(rbacInitProvider.future);  // ISSUE 5: Start claims sync"),
        ("ref.read(isLoggedInProvider.notifier).state = true;", "ref.read(isLoggedInProvider.notifier).state = true;\n    ref.read(rbacInitProvider.future);  // ISSUE 5: Start claims sync"),
    ]

    added = 0
    for old, new in patterns_to_find:
        if old in content and "rbacInitProvider" not in content:
            content = content.replace(old, new, 1)  # only first occurrence per pattern
            added += 1

    if added > 0:
        # Add import for rbacInitProvider if not present
        if "rbac_provider" not in content:
            lines = content.split("\n")
            last_import = -1
            for i, line in enumerate(lines):
                if line.startswith("import "): last_import = i
            if last_import >= 0:
                lines.insert(last_import + 1, "import '../providers/rbac_provider.dart';")
                content = "\n".join(lines)

        auth_path.write_text(content, encoding="utf-8")
        print(f"  [OK] Wired up rbacInitProvider ({added} location(s))")
        fixes.append("Issue 5: RBAC init")
    elif "rbacInitProvider" in content:
        print("  [OK] Already wired up (skipping)")
    else:
        print("  [!] Could not find login pattern — add manually:")
        print("      After login success: ref.read(rbacInitProvider.future);")
print()

# Also check the features/auth/providers/ duplicate
dup_path = Path("lib/features/auth/providers/auth_provider.dart")
if dup_path.exists():
    dup_content = dup_path.read_text(encoding="utf-8")
    for old, new in patterns_to_find:
        if old in dup_content and "rbacInitProvider" not in dup_content:
            dup_content = dup_content.replace(old, new, 1)
            if "rbac_provider" not in dup_content:
                lines = dup_content.split("\n")
                last_import = -1
                for i, line in enumerate(lines):
                    if line.startswith("import "): last_import = i
                if last_import >= 0:
                    lines.insert(last_import + 1, "import '../../../providers/rbac_provider.dart';")
                    dup_content = "\n".join(lines)
            dup_path.write_text(dup_content, encoding="utf-8")
            print(f"  [OK] Also fixed {dup_path}")
            break

# ============================================================================
# syncClaims: increment roleVersion (defense in depth)
# ============================================================================
print("--- syncClaims: increment roleVersion ---")

sc_path = Path("functions/src/functions/syncClaims.ts")
if sc_path.exists():
    content = sc_path.read_text(encoding="utf-8")

    # After setCustomUserClaims, add roleVersion increment
    old Claims = "await admin.auth().setCustomUserClaims("
    # This is complex to patch reliably — flag for manual
    if "roleVersion" not in content.split("setCustomUserClaims")[1][:500] if "setCustomUserClaims" in content else True:
        print("  [!] Manual fix needed in syncClaims.ts:")
        print("      After setCustomUserClaims, add:")
        print("      await db.collection('users').doc(targetUserId).set(")
        print("        { roleVersion: FieldValue.increment(1) }, { merge: true }")
        print("      );")
    else:
        print("  [OK] roleVersion increment already present")
print()

# ============================================================================
# P0-9: Dashboard flicker — skipLoadingOnReload (30 min)
# ============================================================================
print("--- P0-9: Fix dashboard flicker (skipLoadingOnReload) ---")

for prov_str in ["lib/providers/student_provider.dart", "lib/providers/class_provider.dart",
                  "lib/providers/exam_provider.dart", "lib/providers/stage_provider.dart"]:
    fp = Path(prov_str)
    if not fp.exists():
        print(f"  [SKIP] {prov_str} not found"); continue

    content = fp.read_text(encoding="utf-8")

    # Replace .when( with .when(skipLoadingOnReload: true,
    old_when = ".when("
    new_when = ".when(skipLoadingOnReload: true,"

    count = content.count(old_when)
    if count > 0 and "skipLoadingOnReload" not in content:
        content = content.replace(old_when, new_when)
        fp.write_text(content, encoding="utf-8")
        print(f"  [OK] {prov_str}: {count} .when() call(s) updated with skipLoadingOnReload: true")
        fixes.append("P0-9: Dashboard flicker")
    elif "skipLoadingOnReload" in content:
        print(f"  [OK] {prov_str}: already has skipLoadingOnReload")
    else:
        print(f"  [SKIP] {prov_str}: no .when() calls found")
print()

# ============================================================================
# Summary + Build + Commit
# ============================================================================
print("=" * 70); print("SUMMARY"); print("=" * 70)
print(f"\nFixes applied: {len(fixes)}")
for f in fixes: print(f"  ✅ {f}")
print()

if not args.no_build:
    print("=" * 70); print("Building functions"); print("=" * 70)
    os.chdir("functions")
    try:
        r = subprocess.run(["npm","run","build"],shell=True)
        if r.returncode != 0: print("\n[WARNING] Build failed")
        else: print("\n  [OK] Build succeeded")
    finally: os.chdir("..")
    print()

print("=" * 70); print("Committing"); print("=" * 70)
msg = """fix(day2): RBAC init + mustChangePassword + Excel password + dashboard flicker

P0-6: Added mustChangePassword: true to createStudent.ts
  - Students will now be forced to change password on first login
  - Combined with C-18 (/change-password route), first-login flow works

P0-7: Replaced sentinel password 'CHANGED_USE_HASHER' with
  PasswordHasher.instance.generateTemporaryPassword() in student_service.dart
  and excel_import_service.dart
  - Each imported student now gets a unique random password

Issue 5: Wired up rbacInitProvider on login
  - rbacInitProvider was defined but NEVER called (dead code)
  - Added ref.read(rbacInitProvider.future) after login success
  - Claims sync listener now starts, role changes propagate in real-time

P0-9: Added skipLoadingOnReload: true to .when() calls in
  student_provider, class_provider, exam_provider, stage_provider
  - Dashboard metrics no longer flicker to 0 on pull-to-refresh

Manual fix needed:
  - syncClaims.ts: add roleVersion increment after setCustomUserClaims
  - This ensures the claims listener fires when syncClaims is called

Verified against commit dbeacd7."""

subprocess.run(["git","add","-A"],check=True)
r = subprocess.run(["git","commit","-m",msg],capture_output=True,text=True)
if r.returncode != 0: print(f"[ERROR] {r.stderr}"); sys.exit(1)
new_commit = subprocess.check_output(["git","rev-parse","--short","HEAD"],text=True).strip()
print(f"\n  [OK] Commit: {new_commit}\n")

if args.no_push: print("[!] Skipping push"); sys.exit(0)
resp = input("Push to origin? (y/n): ").strip().lower()
if resp == "y":
    r = subprocess.run(["git","push","origin","main"])
    if r.returncode != 0: print("\n[ERROR] Push failed"); sys.exit(1)
    print(f"\n  [OK] Pushed: https://github.com/Strike87/Klasivo/commit/{new_commit}")
else: print("[!] Skipped")

print(f"\nRollback: git reset --hard {backup}")
