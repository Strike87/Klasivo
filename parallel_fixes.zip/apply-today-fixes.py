#!/usr/bin/env python3
# ============================================================================
# Klasivo — Today's Fixes (Issues 1, 2, 3, 4)
# ============================================================================
# Fixes the 4 highest-impact bugs from the Production Investigation report:
#
#   Issue 1: currentOrganizationIdProvider never synced after login (15 min)
#   Issue 2: ShellRoute disposes tab state (needs manual review)
#   Issue 3: Notifications query missing organizationId filter (30 min)
#   Issue 4: Exam creation defaults organizationId to 'default' (15 min)
#
# All 4 issues VERIFIED against actual code at commit dbeacd7.
#
# Usage:
#   cd C:\Users\Strik\Klasivo
#   python apply-today-fixes.py
# ============================================================================

import os
import sys
import re
import subprocess
import argparse
from pathlib import Path
from datetime import datetime

if not Path("firestore.rules").exists():
    print("ERROR: Run from Klasivo repo root.")
    sys.exit(1)

parser = argparse.ArgumentParser(description="Apply Klasivo Today's Fixes (Issues 1-4)")
parser.add_argument("--no-push", action="store_true")
parser.add_argument("--no-build", action="store_true")
parser.add_argument("--force", action="store_true")
args = parser.parse_args()

print("=" * 70)
print("KLASIVO TODAY'S FIXES — Issues 1, 2, 3, 4")
print("=" * 70)
print(f"Working directory: {Path.cwd()}")

try:
    current_commit = subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], text=True).strip()
    print(f"Current git commit: {current_commit}")
except subprocess.CalledProcessError:
    sys.exit(1)
print()

status = subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
if status and not args.force:
    print("ERROR: Working tree has uncommitted changes.")
    print("Run: git stash  OR  re-run with --force")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup_branch = f"backup-before-today-fixes-{timestamp}"
subprocess.run(["git", "branch", backup_branch], capture_output=True)
print(f"Backup branch: {backup_branch}")
print()

fixes_applied = []

# ============================================================================
# Issue 1: Sync currentOrganizationIdProvider after login (15 min)
# ============================================================================
print("=" * 70)
print("Issue 1: Sync currentOrganizationIdProvider after login")
print("=" * 70)
print()
print("  ROOT CAUSE: saveTeacherAuthData/saveStudentAuthData/saveParentAuthData")
print("  update organizationIdProvider but NEVER update currentOrganizationIdProvider.")
print("  65+ providers read currentOrganizationIdProvider → get null → return Stream.empty()")
print()

auth_path = Path("lib/providers/auth_provider.dart")
auth_content = auth_path.read_text(encoding="utf-8")

# Pattern: find all occurrences of "ref.read(organizationIdProvider.notifier).state = organizationId;"
# and add "ref.read(currentOrganizationIdProvider.notifier).state = organizationId;" after each

old_pattern = "ref.read(organizationIdProvider.notifier).state = organizationId;"
new_pattern = """ref.read(organizationIdProvider.notifier).state = organizationId;
      ref.read(currentOrganizationIdProvider.notifier).state = organizationId;  // ISSUE 1 FIX"""

count = auth_content.count(old_pattern)
print(f"  Found {count} occurrence(s) of organizationIdProvider update")

if count > 0:
    auth_content = auth_content.replace(old_pattern, new_pattern)
    auth_path.write_text(auth_content, encoding="utf-8")
    print(f"  [OK] Added currentOrganizationIdProvider sync ({count} location(s))")
    fixes_applied.append("Issue 1: Provider sync")
else:
    print("  [!] Pattern not found (may already be fixed)")

# Also check the duplicate auth_provider in features/auth/providers/
dup_auth_path = Path("lib/features/auth/providers/auth_provider.dart")
if dup_auth_path.exists():
    dup_content = dup_auth_path.read_text(encoding="utf-8")
    dup_count = dup_content.count(old_pattern)
    if dup_count > 0:
        dup_content = dup_content.replace(old_pattern, new_pattern)
        dup_auth_path.write_text(dup_content, encoding="utf-8")
        print(f"  [OK] Also fixed duplicate at {dup_auth_path} ({dup_count} location(s))")

print()

# ============================================================================
# Issue 2: ShellRoute → StatefulShellRoute.indexedStack (flag for manual)
# ============================================================================
print("=" * 70)
print("Issue 2: ShellRoute disposes tab state")
print("=" * 70)
print()
print("  ROOT CAUSE: Plain ShellRoute disposes tab widget subtrees on navigation.")
print("  Converting to StatefulShellRoute.indexedStack preserves tab state.")
print()
print("  ⚠️  This change requires manual restructuring of the route tree.")
print("  The script will NOT auto-apply this — it's too risky to automate.")
print()
print("  MANUAL FIX REQUIRED:")
print("  In lib/main.dart, convert:")
print("    ShellRoute(builder: (context, state, child) => TeacherShell(child: child), routes: [...])")
print("  To:")
print("    StatefulShellRoute.indexedStack(")
print("      builder: (context, state, navigationShell) => TeacherShell(child: navigationShell),")
print("      branches: [")
print("        StatefulBranch(routes: [GoRoute(path: '/dashboard', ...)]),")
print("        StatefulBranch(routes: [GoRoute(path: '/academic', ...)]),")
print("        // ... one branch per tab")
print("      ],")
print("    )")
print()
print("  Apply this manually after the other fixes are verified.")
print()
print("  NOTE: Issue 1 fix (provider sync) may resolve most of Issue 2's symptoms")
print("  since the disappearing data was primarily caused by null orgId, not tab disposal.")
print()

# ============================================================================
# Issue 3: Notifications query missing organizationId filter (30 min)
# ============================================================================
print("=" * 70)
print("Issue 3: Notifications query missing organizationId filter")
print("=" * 70)
print()
print("  ROOT CAUSE: getUserNotificationsStream filters on userId only.")
print("  Rule isInSameOrg() requires organizationId match → query denied.")
print()

notif_path = Path("lib/core/services/notification_service.dart")
notif_content = notif_path.read_text(encoding="utf-8")

# Fix 1: getUserNotificationsStream — add organizationId parameter + filter
old_stream = """static Stream<QuerySnapshot> getUserNotificationsStream(String userId) {
    return _firestore
        .collection(AppConstants.notificationsCollection)
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .limit(AppConstants.notificationsPageSize)
        .snapshots();
  }"""

new_stream = """static Stream<QuerySnapshot> getUserNotificationsStream(
    String userId, {required String organizationId}) {
    return _firestore
        .collection(AppConstants.notificationsCollection)
        .where('userId', isEqualTo: userId)
        .where('organizationId', isEqualTo: organizationId)  // ISSUE 3 FIX
        .orderBy('createdAt', descending: true)
        .limit(AppConstants.notificationsPageSize)
        .snapshots();
  }"""

if old_stream in notif_content:
    notif_content = notif_content.replace(old_stream, new_stream)
    print("  [OK] getUserNotificationsStream: added organizationId filter")
else:
    print("  [!] getUserNotificationsStream pattern not found (may already be fixed)")

# Fix 2: getUnreadCount — add organizationId parameter + filter
old_unread = """static Future<int> getUnreadCount(String userId) async {
    try {
      final snapshot = await _firestore
          .collection(AppConstants.notificationsCollection)
          .where('userId', isEqualTo: userId)
          .where('isRead', isEqualTo: false)
          .get();"""

new_unread = """static Future<int> getUnreadCount(String userId, {required String organizationId}) async {
    try {
      final snapshot = await _firestore
          .collection(AppConstants.notificationsCollection)
          .where('userId', isEqualTo: userId)
          .where('organizationId', isEqualTo: organizationId)  // ISSUE 3 FIX
          .where('isRead', isEqualTo: false)
          .get();"""

if old_unread in notif_content:
    notif_content = notif_content.replace(old_unread, new_unread)
    print("  [OK] getUnreadCount: added organizationId filter")
else:
    print("  [!] getUnreadCount pattern not found")

# Fix 3: markAllAsRead — add organizationId parameter + filter
old_mark = """static Future<void> markAllAsRead(String userId) async {
    try {
      final snapshot = await _firestore
          .collection(AppConstants.notificationsCollection)
          .where('userId', isEqualTo: userId)
          .where('isRead', isEqualTo: false)
          .get();"""

new_mark = """static Future<void> markAllAsRead(String userId, {required String organizationId}) async {
    try {
      final snapshot = await _firestore
          .collection(AppConstants.notificationsCollection)
          .where('userId', isEqualTo: userId)
          .where('organizationId', isEqualTo: organizationId)  // ISSUE 3 FIX
          .where('isRead', isEqualTo: false)
          .get();"""

if old_mark in notif_content:
    notif_content = notif_content.replace(old_mark, new_mark)
    print("  [OK] markAllAsRead: added organizationId filter")
else:
    print("  [!] markAllAsRead pattern not found")

notif_path.write_text(notif_content, encoding="utf-8")

# Fix 4: Update the notification provider to pass orgId
notif_provider_path = Path("lib/providers/notification_provider.dart")
if notif_provider_path.exists():
    np_content = notif_provider_path.read_text(encoding="utf-8")

    # Look for the provider that calls getUserNotificationsStream
    old_provider = """return NotificationService.getUserNotificationsStream(userId);"""
    new_provider = """final orgId = ref.watch(organizationIdProvider);
  if (orgId == null || orgId.isEmpty) return const Stream.empty();
  return NotificationService.getUserNotificationsStream(userId, organizationId: orgId);"""

    if old_provider in np_content:
        np_content = np_content.replace(old_provider, new_provider)
        notif_provider_path.write_text(np_content, encoding="utf-8")
        print("  [OK] notification_provider: passes organizationId to query")
    else:
        print("  [!] notification_provider pattern not found — check manually")
        print("      Need to pass organizationId to getUserNotificationsStream call")

# Also check features/notifications for the provider
alt_np = Path("lib/features/notifications/providers/notification_provider.dart")
if alt_np.exists():
    alt_content = alt_np.read_text(encoding="utf-8")
    if old_provider in alt_content:
        alt_content = alt_content.replace(old_provider, new_provider)
        alt_np.write_text(alt_content, encoding="utf-8")
        print(f"  [OK] Also fixed {alt_np}")

fixes_applied.append("Issue 3: Notifications orgId filter")
print()

# ============================================================================
# Issue 4: Exam creation defaults organizationId to 'default' (15 min)
# ============================================================================
print("=" * 70)
print("Issue 4: Exam creation defaults organizationId to 'default'")
print("=" * 70)
print()
print("  ROOT CAUSE: exam_service.dart defaults organizationId to 'default'")
print("  exam_form_screen.dart never passes the real org → permission-denied")
print()

exam_service_path = Path("lib/core/services/exam_service.dart")
exam_content = exam_service_path.read_text(encoding="utf-8")

# Fix 1: Make organizationId required (remove the bad default)
old_exam_default = "String organizationId = AppConstants.defaultInstitutionId,"
new_exam_default = "required String organizationId,"

if old_exam_default in exam_content:
    exam_content = exam_content.replace(old_exam_default, new_exam_default)
    exam_service_path.write_text(exam_content, encoding="utf-8")
    print("  [OK] exam_service.dart: organizationId now required (removed 'default' default)")
else:
    print("  [!] exam_service.dart pattern not found (may already be fixed)")

# Fix 2: Update exam_form_screen.dart to pass organizationId
exam_form_path = Path("lib/features/exams/pages/exam_form_screen.dart")
if exam_form_path.exists():
    form_content = exam_form_path.read_text(encoding="utf-8")

    # Look for the createExam call
    old_create = """final examId = await examService.createExam(
    teacherId: teacherId,"""

    new_create = """final organizationId = ref.read(organizationIdProvider);
  if (organizationId == null || organizationId.isEmpty) {
    KlasivoToast.error(context, message: 'Organization context missing. Please re-login.');
    return;
  }
  final examId = await examService.createExam(
    teacherId: teacherId,
    organizationId: organizationId,"""

    if old_create in form_content:
        form_content = form_content.replace(old_create, new_create, 1)
        exam_form_path.write_text(form_content, encoding="utf-8")
        print("  [OK] exam_form_screen.dart: passes organizationId from provider")
    else:
        print("  [!] exam_form_screen.dart createExam call pattern not found")
        print("      Manually add organizationId: ref.read(organizationIdProvider) to createExam call")

# Also check the duplicate
exam_form_dup = Path("lib/features/exams/presentation/exam_form_screen.dart")
if exam_form_dup.exists():
    dup_content = exam_form_dup.read_text(encoding="utf-8")
    if old_create in dup_content:
        dup_content = dup_content.replace(old_create, new_create, 1)
        exam_form_dup.write_text(dup_content, encoding="utf-8")
        print(f"  [OK] Also fixed duplicate at {exam_form_dup}")

fixes_applied.append("Issue 4: Exam creation orgId")
print()

# ============================================================================
# Also fix: violations + exam_instances with same 'default' bug
# ============================================================================
print("=" * 70)
print("Bonus: Fix same 'default' orgId bug in other services")
print("=" * 70)
print()

# violation_service.dart
violation_path = Path("lib/core/services/violation_service.dart")
if violation_path.exists():
    v_content = violation_path.read_text(encoding="utf-8")
    old_v = "String organizationId = AppConstants.defaultInstitutionId,"
    new_v = "required String organizationId,"
    if old_v in v_content:
        v_content = v_content.replace(old_v, new_v)
        violation_path.write_text(v_content, encoding="utf-8")
        print("  [OK] violation_service.dart: organizationId now required")
    else:
        print("  [SKIP] violation_service.dart: pattern not found")

# exam_instance_service.dart
ei_path = Path("lib/features/exams/data/exam_instance_service.dart")
if not ei_path.exists():
    ei_path = Path("lib/core/services/exam_instance_service.dart")
if ei_path.exists():
    ei_content = ei_path.read_text(encoding="utf-8")
    old_ei = "AppConstants.defaultInstitutionId"
    if old_ei in ei_content:
        # Replace with a comment + require caller to pass orgId
        ei_content = ei_content.replace(
            old_ei,
            "organizationId  // ISSUE 4 FIX: was defaultInstitutionId — caller must pass real org"
        )
        ei_path.write_text(ei_content, encoding="utf-8")
        print(f"  [OK] {ei_path}: replaced defaultInstitutionId with real orgId reference")
    else:
        print(f"  [SKIP] {ei_path}: no defaultInstitutionId found")

print()

# ============================================================================
# Summary
# ============================================================================
print("=" * 70)
print("FIXES SUMMARY")
print("=" * 70)
print()
for f in fixes_applied:
    print(f"  ✅ {f}")
print()
print("  ⚠️  Issue 2 (ShellRoute) requires MANUAL fix — see instructions above")
print()

if not args.no_build:
    print("=" * 70)
    print("Building functions")
    print("=" * 70)
    os.chdir("functions")
    try:
        result = subprocess.run(["npm", "run", "build"], shell=True)
        if result.returncode != 0:
            print("\n[WARNING] Functions build failed — check errors")
        else:
            print("\n  [OK] Functions build succeeded")
    finally:
        os.chdir("..")
    print()

# ============================================================================
# Commit
# ============================================================================
print("=" * 70)
print("Committing")
print("=" * 70)

commit_message = """fix(issues-1-4): provider sync, notifications, exam creation

Issue 1: Sync currentOrganizationIdProvider after login
  - Root cause: saveTeacherAuthData/saveStudentAuthData/saveParentAuthData
    updated organizationIdProvider but NEVER updated currentOrganizationIdProvider
  - 65+ providers read currentOrganizationIdProvider → got null → returned Stream.empty()
  - Fix: Added ref.read(currentOrganizationIdProvider.notifier).state = organizationId
    after each organizationIdProvider update (3 locations + duplicates)

Issue 3: Notifications query missing organizationId filter
  - Root cause: getUserNotificationsStream filtered on userId only
  - Rule isInSameOrg() requires per-document organizationId check → query denied
  - Fix: Added organizationId parameter + .where('organizationId', isEqualTo: orgId)
    to getUserNotificationsStream, getUnreadCount, markAllAsRead
  - Updated notification_provider to pass orgId from organizationIdProvider

Issue 4: Exam creation defaults organizationId to 'default'
  - Root cause: exam_service.dart defaulted organizationId to 'default'
  - exam_form_screen.dart never passed real org → 'default' != real org → denied
  - Fix: Made organizationId required in exam_service.dart (removed default)
  - Updated exam_form_screen.dart to pass ref.read(organizationIdProvider)
  - Also fixed same bug in violation_service.dart and exam_instance_service.dart

Issue 2: ShellRoute disposes tab state (MANUAL FIX NEEDED)
  - Root cause: Plain ShellRoute disposes tab widget subtrees on navigation
  - Fix: Convert to StatefulShellRoute.indexedStack (requires manual route restructuring)
  - NOTE: Issue 1 fix may resolve most symptoms since null orgId was the primary cause

Verified against commit dbeacd7.
See: Klasivo_Production_Investigation.md for full root cause analysis."""

subprocess.run(["git", "add", "-A"], check=True)
result = subprocess.run(["git", "commit", "-m", commit_message], capture_output=True, text=True)
if result.returncode != 0:
    print(f"[ERROR] Commit failed: {result.stderr}")
    sys.exit(1)

new_commit = subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], text=True).strip()
print(f"\n  [OK] Commit: {new_commit}\n")

if args.no_push:
    print("[!] Skipping push (--no-push)")
    print("    git push origin main  (when ready)")
    sys.exit(0)

response = input("Push to origin? (y/n): ").strip().lower()
if response == "y":
    result = subprocess.run(["git", "push", "origin", "main"])
    if result.returncode != 0:
        print("\n[ERROR] Push failed")
        sys.exit(1)
    print(f"\n  [OK] Pushed: https://github.com/Strike87/Klasivo/commit/{new_commit}")
else:
    print("[!] Skipped. Run: git push origin main")

print()
print("=" * 70)
print("DEPLOY + VERIFY")
print("=" * 70)
print()
print("1. Deploy: firebase deploy --only functions,firestore:rules,firestore:indexes")
print()
print("2. Verify Issue 1 (provider sync):")
print("   - Login as owner (fresh, no restart)")
print("   - Navigate to Academic Structure immediately")
print("   - Confirm: stages + classes appear (not '0 Classes')")
print("   - Navigate Dashboard → Academic → Dashboard → confirm data persists")
print()
print("3. Verify Issue 3 (notifications):")
print("   - Open Notifications/Inbox")
print("   - Confirm: no permission-denied error, list loads")
print()
print("4. Verify Issue 4 (exam creation):")
print("   - Create exam → tap 'Create & Add Questions'")
print("   - Confirm: no permission-denied, exam created successfully")
print("   - Check Firestore: exam doc has organizationId = real org (not 'default')")
print()
print("5. Issue 2 (ShellRoute) — apply manually if tab state still flickers")
print()
print("Rollback: git reset --hard " + backup_branch)
