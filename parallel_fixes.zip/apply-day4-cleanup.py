#!/usr/bin/env python3
# ============================================================================
# Klasivo Day 4 — Rules Cleanup + Client Migration + ShellRoute
# ============================================================================
# Fixes from Production Investigation report:
#   - Update auth_service.dart to call registerOwner/registerParent CFs
#   - Fix change_password_screen navigation (go_router compatible)
#   - Fix violations rule (add role check)
#   - Fix exam_instances hardcoded 'default' orgId
#   - Convert ShellRoute to StatefulShellRoute.indexedStack (manual)
#   - Final rules cleanup pass
#
# Usage:
#   cd C:\Users\Strik\Klasivo
#   python apply-day4-cleanup.py
# ============================================================================

import os, sys, re, subprocess, argparse
from pathlib import Path
from datetime import datetime

if not Path("firestore.rules").exists():
    print("ERROR: Run from Klasivo repo root."); sys.exit(1)

parser = argparse.ArgumentParser(description="Apply Klasivo Day 4 cleanup")
parser.add_argument("--no-push", action="store_true")
parser.add_argument("--no-build", action="store_true")
parser.add_argument("--force", action="store_true")
args = parser.parse_args()

print("=" * 70); print("KLASIVO DAY 4 — Client Migration + Rules Cleanup"); print("=" * 70)
print(f"Working directory: {Path.cwd()}")

try:
    print(f"Current commit: {subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()}")
except: sys.exit(1)
print()

status = subprocess.check_output(["git","status","--porcelain"],text=True).strip()
if status and not args.force:
    print("ERROR: Working tree has uncommitted changes."); sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = f"backup-before-day4-{timestamp}"
subprocess.run(["git","branch",backup],capture_output=True)
print(f"Backup: {backup}\n")

fixes = []

# ============================================================================
# 1. Update auth_service.dart registerOwner to call CF
# ============================================================================
print("--- 1. Update registerOwner to call Cloud Function ---")

auth_path = Path("lib/core/services/auth_service.dart")
if auth_path.exists():
    content = auth_path.read_text(encoding="utf-8")

    # Find the registerOwner method and replace its body with a CF call
    # Look for "Future<Map<String, dynamic>> registerOwner" and replace the Firestore writes
    # This is complex — we'll add a new method that calls the CF and mark the old one as deprecated

    new_method = '''  /// P0-1 FIX: Register owner via Cloud Function (not client-side writes)
  /// Replaces the old registerOwner that wrote role:'owner' from client
  /// (which was blocked by Firestore rules).
  Future<Map<String, dynamic>> registerOwnerViaCF({
    required String email,
    required String password,
    required String fullName,
    required String organizationName,
    String? phone,
  }) async {
    try {
      final result = await _functions.httpsCallable('registerOwner').call({
        'email': email,
        'password': password,
        'fullName': fullName,
        'organizationName': organizationName,
        'phone': phone,
      });

      final data = result.data as Map<String, dynamic>;
      final uid = data['uid'] as String;
      final orgId = data['organizationId'] as String;

      // Sign in the newly created user
      await _auth.signInWithEmailAndPassword(email: email, password: password);

      // Save auth data
      // (The caller should call saveTeacherAuthData with the returned uid + orgId)

      return {
        'success': true,
        'uid': uid,
        'organizationId': orgId,
        'role': 'owner',
      };
    } on FirebaseFunctionsException catch (e) {
      return {
        'success': false,
        'error': e.message ?? 'Registration failed',
        'code': e.code,
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }
'''

    if "registerOwnerViaCF" not in content:
        # Add the new method before the existing registerOwner
        # Find "Future<Map<String, dynamic>> registerOwner(" and insert before
        old_method_sig = "Future<Map<String, dynamic>> registerOwner("
        if old_method_sig in content:
            content = content.replace(old_method_sig, new_method + "\n  /// DEPRECATED: Use registerOwnerViaCF instead\n  " + old_method_sig)
            auth_path.write_text(content, encoding="utf-8")
            print("  [OK] Added registerOwnerViaCF method (old one marked deprecated)")
            fixes.append("registerOwner CF call")
        else:
            print("  [!] Could not find registerOwner method signature")
    else:
        print("  [OK] registerOwnerViaCF already exists")
print()

# ============================================================================
# 2. Update registerParent to call CF
# ============================================================================
print("--- 2. Update registerParent to call Cloud Function ---")

if auth_path.exists():
    content = auth_path.read_text(encoding="utf-8")

    new_parent_method = '''  /// P0-2 FIX: Register parent via Cloud Function
  Future<Map<String, dynamic>> registerParentViaCF({
    required String email,
    required String password,
    required String fullName,
    String? phone,
    String? studentCode,
  }) async {
    try {
      final result = await _functions.httpsCallable('registerParent').call({
        'email': email,
        'password': password,
        'fullName': fullName,
        'phone': phone,
        'studentCode': studentCode,
      });

      final data = result.data as Map<String, dynamic>;
      final uid = data['uid'] as String;

      // Sign in
      await _auth.signInWithEmailAndPassword(email: email, password: password);

      return {
        'success': true,
        'uid': uid,
        'role': 'parent',
      };
    } on FirebaseFunctionsException catch (e) {
      return {'success': false, 'error': e.message ?? 'Registration failed'};
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }
'''

    if "registerParentViaCF" not in content:
        old_parent_sig = "Future<Map<String, dynamic>> registerParent("
        if old_parent_sig in content:
            content = content.replace(old_parent_sig, new_parent_method + "\n  /// DEPRECATED: Use registerParentViaCF instead\n  " + old_parent_sig)
            auth_path.write_text(content, encoding="utf-8")
            print("  [OK] Added registerParentViaCF method")
            fixes.append("registerParent CF call")
        else:
            print("  [!] Could not find registerParent method signature")
    else:
        print("  [OK] registerParentViaCF already exists")
print()

# ============================================================================
# 3. Fix change_password_screen navigation (P1-4)
# ============================================================================
print("--- 3. Fix change_password_screen navigation ---")

cp_path = Path("lib/features/auth/pages/change_password_screen.dart")
if cp_path.exists():
    content = cp_path.read_text(encoding="utf-8")

    # Replace Navigator.pushReplacementNamed with context.go
    old_nav = "Navigator.of(context).pushReplacementNamed('/dashboard');"
    new_nav = "context.go('/dashboard');  // P1-4: go_router compatible"

    if old_nav in content:
        content = content.replace(old_nav, new_nav)
        # Also try context.pushReplacement
        old_nav2 = "Navigator.pushReplacementNamed(context, '/dashboard');"
        new_nav2 = "context.go('/dashboard');"
        content = content.replace(old_nav2, new_nav2)

        cp_path.write_text(content, encoding="utf-8")
        print("  [OK] Fixed navigation to use context.go (go_router)")
        fixes.append("P1-4: Change password navigation")
    else:
        print("  [!] Navigation pattern not found — check manually")
print()

# ============================================================================
# 4. Fix violations rule — add role check
# ============================================================================
print("--- 4. Fix violations rule (add role check) ---")

rules_path = Path("firestore.rules")
rules_content = rules_path.read_text(encoding="utf-8")

old_violations = "match /violations/{violationId} {\n      allow read: if isAuth() && isInSameOrg();\n      allow create: if isAuth() && isIncomingSameOrg();"
new_violations = "match /violations/{violationId} {\n      allow read: if isAuth() && isInSameOrg();\n      allow create: if isAuth() && isIncomingSameOrg() &&\n        (isStaff() || request.resource.data.studentId == request.auth.uid);  // Day 4: role check"

if old_violations in rules_content:
    rules_content = rules_content.replace(old_violations, new_violations)
    rules_path.write_text(rules_content, encoding="utf-8")
    print("  [OK] Violations create: added role check (staff or self)")
    fixes.append("Rules: violations role check")
else:
    print("  [!] Violations rule pattern not found")
print()

# ============================================================================
# 5. Fix exam_instances hardcoded 'default' orgId
# ============================================================================
print("--- 5. Fix exam_instances hardcoded orgId ---")

ei_path = Path("lib/features/exams/data/exam_instance_service.dart")
if not ei_path.exists():
    ei_path = Path("lib/core/services/exam_instance_service.dart")
if ei_path.exists():
    content = ei_path.read_text(encoding="utf-8")

    # Replace any remaining defaultInstitutionId references
    if "defaultInstitutionId" in content:
        content = content.replace(
            "AppConstants.defaultInstitutionId",
            "organizationId  // Day 4: use real org, not default"
        )
        ei_path.write_text(content, encoding="utf-8")
        print(f"  [OK] {ei_path.name}: replaced defaultInstitutionId")
        fixes.append("exam_instances orgId")
    else:
        print("  [OK] No defaultInstitutionId references (already fixed)")
print()

# ============================================================================
# 6. ShellRoute → StatefulShellRoute (flag for manual)
# ============================================================================
print("--- 6. ShellRoute → StatefulShellRoute (MANUAL) ---")
print()
print("  ⚠️  This requires manual route tree restructuring.")
print("  The script will NOT auto-apply — too risky to automate.")
print()
print("  After applying all other fixes and verifying, if tab state")
print("  still flickers, convert ShellRoute to StatefulShellRoute.indexedStack")
print("  in lib/main.dart (lines 762 and 924).")
print()
print("  See: https://pub.dev/documentation/go_router/latest/go_router/StatefulShellRoute-class.html")
print()

# ============================================================================
# 7. Fix duplicate auth_provider.dart — delete dead copies
# ============================================================================
print("--- 7. Delete dead duplicate auth_provider files ---")

dup_files = [
    "lib/features/auth/providers/auth_provider.dart",
    "lib/app/app_providers.dart",
]

for dup_str in dup_files:
    dup = Path(dup_str)
    if dup.exists():
        # Check if it's actually imported by main.dart or other live code
        # For safety, we'll just flag it
        print(f"  [FLAG] {dup_str} exists — verify it's dead code before deleting")
    else:
        print(f"  [SKIP] {dup_str} not found")
print()

# ============================================================================
# Summary + Build + Commit
# ============================================================================
print("=" * 70); print("SUMMARY"); print("=" * 70)
print(f"\nFixes applied: {len(fixes)}")
for f in fixes: print(f"  ✅ {f}")
print()
print("Manual work still needed:")
print("  1. Update owner_register_screen.dart to call registerOwnerViaCF instead of registerOwner")
print("  2. Update parent_register_screen.dart to call registerParentViaCF")
print("  3. Update teacher_registration to call redeemInviteCode CF")
print("  4. Convert ShellRoute to StatefulShellRoute.indexedStack if tab flicker persists")
print("  5. Delete dead duplicate auth_provider files after verifying no imports")
print("  6. syncClaims.ts: add roleVersion increment (manual)")
print()

if not args.no_build:
    print("=" * 70); print("Building functions"); print("=" * 70)
    os.chdir("functions")
    try:
        r = subprocess.run(["npm","run","build"],shell=True)
        if r.returncode != 0: print("\n[WARNING] Build failed")
        else: print("\n  [OK] Build succeeded")
    finally: os.chdir("..")
    print()

print("=" * 70); print("Committing"); print("=" * 70)
msg = """fix(day4): client migration + rules cleanup + navigation

1. Added registerOwnerViaCF method to auth_service.dart
   - Calls registerOwner Cloud Function (created in Day 3)
   - Old registerOwner marked as DEPRECATED

2. Added registerParentViaCF method to auth_service.dart
   - Calls registerParent Cloud Function

3. Fixed change_password_screen navigation
   - Replaced Navigator.pushReplacementNamed with context.go
   - Now compatible with go_router

4. Fixed violations rule — added role check
   - create now requires isStaff() OR studentId == auth.uid
   - Prevents students from spamming violations against peers

5. Fixed exam_instances — replaced defaultInstitutionId with real orgId

Manual work still needed:
  - Update screens to call *ViaCF methods
  - Convert ShellRoute to StatefulShellRoute.indexedStack
  - Delete dead duplicate auth_provider files
  - syncClaims.ts: add roleVersion increment

Verified against commit dbeacd7."""

subprocess.run(["git","add","-A"],check=True)
r = subprocess.run(["git","commit","-m",msg],capture_output=True,text=True)
if r.returncode != 0: print(f"[ERROR] {r.stderr}"); sys.exit(1)
new_commit = subprocess.check_output(["git","rev-parse","--short","HEAD"],text=True).strip()
print(f"\n  [OK] Commit: {new_commit}\n")

if args.no_push: print("[!] Skipping push"); sys.exit(0)
resp = input("Push to origin? (y/n): ").strip().lower()
if resp == "y":
    r = subprocess.run(["git","push","origin","main"])
    if r.returncode != 0: print("\n[ERROR] Push failed"); sys.exit(1)
    print(f"\n  [OK] Pushed: https://github.com/Strike87/Klasivo/commit/{new_commit}")
else: print("[!] Skipped")

print(f"\nRollback: git reset --hard {backup}")
