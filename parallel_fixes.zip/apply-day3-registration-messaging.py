#!/usr/bin/env python3
# ============================================================================
# Klasivo Day 3 — Owner/Parent Registration CFs + Messaging Fix
# ============================================================================
# Fixes from Production Investigation report:
#   P0-1: Owner registration impossible → create registerOwner CF
#   P0-2: Parent registration impossible → create registerParent CF
#   P0-3: Owners/teachers never get claims → CFs set claims
#   P0-5: Messaging completely broken → fix participants vs participantIds + add orgId
#   Rules: Add 'owner' to users create, fix conversations/messages rules
#
# Usage:
#   cd C:\Users\Strik\Klasivo
#   python apply-day3-registration-messaging.py
# ============================================================================

import os, sys, re, subprocess, argparse
from pathlib import Path
from datetime import datetime

if not Path("firestore.rules").exists():
    print("ERROR: Run from Klasivo repo root."); sys.exit(1)

parser = argparse.ArgumentParser(description="Apply Klasivo Day 3 fixes")
parser.add_argument("--no-push", action="store_true")
parser.add_argument("--no-build", action="store_true")
parser.add_argument("--force", action="store_true")
args = parser.parse_args()

print("=" * 70); print("KLASIVO DAY 3 — Registration CFs + Messaging"); print("=" * 70)
print(f"Working directory: {Path.cwd()}")

try:
    print(f"Current commit: {subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()}")
except: sys.exit(1)
print()

status = subprocess.check_output(["git","status","--porcelain"],text=True).strip()
if status and not args.force:
    print("ERROR: Working tree has uncommitted changes. Use --force or git stash"); sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = f"backup-before-day3-{timestamp}"
subprocess.run(["git","branch",backup],capture_output=True)
print(f"Backup: {backup}\n")

fixes = []

def write_file(filepath, content):
    p = Path(filepath)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    print(f"  [OK] Created {p}")

# ============================================================================
# P0-1: Create registerOwner Cloud Function
# ============================================================================
print("=" * 70); print("P0-1: Create registerOwner Cloud Function"); print("=" * 70); print()

write_file("functions/src/functions/registerOwner.ts", '''/**
 * registerOwner — P0-1: Owner registration via Cloud Function
 *
 * Previous: client wrote role:'owner' → Firestore rules rejected it
 * (rules only allow student/parent/teacher on self-create).
 * No CF existed → owner registration was impossible.
 *
 * This CF:
 * 1. Creates Firebase Auth account
 * 2. Creates organization doc
 * 3. Creates user doc with role:'owner' + real organizationId
 * 4. Sets custom claims (role, organizationId, roleVersion)
 * 5. Writes audit log
 * 6. Returns the new user's UID + org ID
 */

import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { initSentry, withIsolatedScope } from '../config/sentry';

interface RegisterOwnerData {
  email: string;
  password: string;
  fullName: string;
  organizationName: string;
  phone?: string;
}

export const registerOwner = onCall(
  {
    secrets: ['SENTRY_DSN'],
    enforceAppCheck: true,
    region: 'us-central1',
    memory: '256MiB',
    timeoutSeconds: 60,
    minInstances: 0,
    maxInstances: 10,
    concurrency: 80,
  },
  async (request) => {
    initSentry();
    return withIsolatedScope(async (scope) => {
      scope.setTag('service', 'auth');
      scope.setTag('function', 'registerOwner');

      const data = request.data as RegisterOwnerData;

      // Validate inputs
      if (!data.email || !data.password || !data.fullName || !data.organizationName) {
        throw new HttpsError('invalid-argument', 'email, password, fullName, organizationName are required.');
      }
      if (data.password.length < 6) {
        throw new HttpsError('invalid-argument', 'Password must be at least 6 characters.');
      }

      const auth = getAuth();
      const db = getFirestore();

      let authUser;
      let orgId: string;

      try {
        // 1. Create Auth account
        authUser = await auth.createUser({
          email: data.email.trim().toLowerCase(),
          password: data.password,
          displayName: data.fullName.trim(),
        });

        // 2. Create organization
        const orgRef = await db.collection('organizations').add({
          name: data.organizationName.trim(),
          ownerId: authUser.uid,
          slug: data.organizationName.trim().toLowerCase().replace(/[^a-z0-9]/g, '-'),
          plan: 'free',
          isActive: true,
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
        });
        orgId = orgRef.id;

        // 3. Create user doc with role:owner + real orgId
        await db.collection('users').doc(authUser.uid).set({
          email: data.email.trim().toLowerCase(),
          fullName: data.fullName.trim(),
          phone: data.phone || null,
          role: 'owner',
          organizationId: orgId,
          tenantId: 'default',
          isActive: true,
          hasCompletedSetup: false,
          authProvider: 'email',
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
          roleVersion: 1,
        });

        // 4. Set custom claims
        await auth.setCustomUserClaims(authUser.uid, {
          role: 'owner',
          organizationId: orgId,
          tenantId: 'default',
          roleVersion: 1,
        });

        // 5. Audit log
        await db.collection('audit_logs').add({
          organizationId: orgId,
          performedBy: authUser.uid,
          performedByRole: 'owner',
          performedByOrgId: orgId,
          action: 'register_owner',
          targetType: 'user',
          targetId: authUser.uid,
          metadata: { email: data.email, organizationName: data.organizationName },
          timestamp: FieldValue.serverTimestamp(),
          serverVerified: true,
        });

        return {
          success: true,
          uid: authUser.uid,
          organizationId: orgId,
        };
      } catch (error: unknown) {
        // Rollback: delete Auth account if created
        if (authUser) {
          try { await auth.deleteUser(authUser.uid); } catch {}
        }
        // Rollback: delete org if created
        if (orgId) {
          try { await db.collection('organizations').doc(orgId).delete(); } catch {}
        }

        const msg = error instanceof Error ? error.message : String(error);
        console.error('registerOwner failed:', msg);
        throw new HttpsError('internal', `Registration failed: ${msg}`);
      }
    });
  },
);
''')

fixes.append("P0-1: registerOwner CF")
print()

# ============================================================================
# P0-2: Create registerParent Cloud Function
# ============================================================================
print("=" * 70); print("P0-2: Create registerParent Cloud Function"); print("=" * 70); print()

write_file("functions/src/functions/registerParent.ts", '''/**
 * registerParent — P0-2: Parent registration via Cloud Function
 *
 * Previous: client wrote organizationId:null → rules rejected (is string fails on null)
 */

import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { initSentry, withIsolatedScope } from '../config/sentry';

interface RegisterParentData {
  email: string;
  password: string;
  fullName: string;
  phone?: string;
  studentCode?: string;  // Optional: link to student immediately
}

export const registerParent = onCall(
  {
    secrets: ['SENTRY_DSN'],
    enforceAppCheck: true,
    region: 'us-central1',
    memory: '256MiB',
    timeoutSeconds: 60,
    minInstances: 0,
    maxInstances: 10,
    concurrency: 80,
  },
  async (request) => {
    initSentry();
    return withIsolatedScope(async (scope) => {
      scope.setTag('service', 'auth');
      scope.setTag('function', 'registerParent');

      const data = request.data as RegisterParentData;

      if (!data.email || !data.password || !data.fullName) {
        throw new HttpsError('invalid-argument', 'email, password, fullName are required.');
      }

      const auth = getAuth();
      const db = getFirestore();

      let authUser;

      try {
        authUser = await auth.createUser({
          email: data.email.trim().toLowerCase(),
          password: data.password,
          displayName: data.fullName.trim(),
        });

        // Create user doc — organizationId will be set when parent links to a student
        await db.collection('users').doc(authUser.uid).set({
          email: data.email.trim().toLowerCase(),
          fullName: data.fullName.trim(),
          phone: data.phone || null,
          role: 'parent',
          organizationId: '',  // Empty string (not null) — passes 'is string' rule
          tenantId: 'default',
          isActive: true,
          authProvider: 'email',
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
          roleVersion: 1,
        });

        // Set custom claims
        await auth.setCustomUserClaims(authUser.uid, {
          role: 'parent',
          organizationId: '',
          tenantId: 'default',
          roleVersion: 1,
        });

        // If studentCode provided, create parent_link
        if (data.studentCode) {
          const studentSnapshot = await db.collection('users')
            .where('studentCode', '==', data.studentCode)
            .limit(1)
            .get();

          if (!studentSnapshot.empty) {
            const studentDoc = studentSnapshot.docs[0];
            const studentOrgId = studentDoc.data()['organizationId'] as string;

            // Update parent's org to match student's org
            await db.collection('users').doc(authUser.uid).update({
              organizationId: studentOrgId,
            });

            await auth.setCustomUserClaims(authUser.uid, {
              role: 'parent',
              organizationId: studentOrgId,
              tenantId: 'default',
              roleVersion: 2,
            });

            // Create parent_link
            await db.collection('parent_links').doc(`${authUser.uid}_${studentDoc.id}`).set({
              parentId: authUser.uid,
              studentId: studentDoc.id,
              organizationId: studentOrgId,
              status: 'pending',
              createdAt: FieldValue.serverTimestamp(),
            });
          }
        }

        return { success: true, uid: authUser.uid };
      } catch (error: unknown) {
        if (authUser) {
          try { await auth.deleteUser(authUser.uid); } catch {}
        }
        const msg = error instanceof Error ? error.message : String(error);
        throw new HttpsError('internal', `Parent registration failed: ${msg}`);
      }
    });
  },
);
''')

fixes.append("P0-2: registerParent CF")
print()

# ============================================================================
# Export new functions in index.ts
# ============================================================================
print("--- Export new functions ---")
index_path = Path("functions/src/index.ts")
index_content = index_path.read_text(encoding="utf-8")

for export_line in [
    "export { registerOwner } from './functions/registerOwner';",
    "export { registerParent } from './functions/registerParent';",
]:
    fn_name = export_line.split("{")[1].split("}")[0].strip()
    if fn_name not in index_content:
        export_matches = list(re.finditer(r'^export \{[^}]+\} from', index_content, re.MULTILINE))
        if export_matches:
            last_export = export_matches[-1]
            line_end = index_content.find('\n', last_export.end())
            if line_end != -1:
                index_content = index_content[:line_end + 1] + export_line + '\n' + index_content[line_end + 1:]

index_path.write_text(index_content, encoding="utf-8")
print("  [OK] Exported registerOwner + registerParent")
print()

# ============================================================================
# P0-5: Fix messaging — participants vs participantIds + add organizationId
# ============================================================================
print("=" * 70); print("P0-5: Fix messaging field mismatches"); print("=" * 70); print()

# Fix messaging_service.dart
msg_path = Path("lib/core/services/messaging_service.dart")
if msg_path.exists():
    content = msg_path.read_text(encoding="utf-8")

    # Rename participantIds → participants in code (to match rules)
    # OR rename in rules. We'll rename in CODE (fewer changes, rules are harder to test)
    old_field = "'participantIds'"
    new_field = "'participants'"

    count = content.count(old_field)
    if count > 0:
        content = content.replace(old_field, new_field)
        print(f"  [OK] messaging_service.dart: renamed participantIds → participants ({count} occurrences)")

    # Add organizationId to message writes
    old_msg_set = "'senderId': senderId,"
    new_msg_set = "'senderId': senderId,\n        'organizationId': organizationId,"

    if old_msg_set in content and "'organizationId': organizationId" not in content:
        content = content.replace(old_msg_set, new_msg_set, 1)
        print("  [OK] messaging_service.dart: added organizationId to message writes")

    # Also fix sender name field: 'name' → 'fullName'
    old_name = "senderDoc.data()?['name']"
    new_name = "senderDoc.data()?['fullName']"
    if old_name in content:
        content = content.replace(old_name, new_name)
        print("  [OK] messaging_service.dart: fixed sender name field (name → fullName)")

    msg_path.write_text(content, encoding="utf-8")
    fixes.append("P0-5: Messaging fix")
else:
    print("  [!] messaging_service.dart not found")

# Also fix messaging_repository.dart
msg_repo = Path("lib/infrastructure/repositories/messaging_repository.dart")
if not msg_repo.exists():
    msg_repo = Path("lib/core/services/messaging_repository.dart")
if msg_repo.exists():
    content = msg_repo.read_text(encoding="utf-8")
    count = content.count("'participantIds'")
    if count > 0:
        content = content.replace("'participantIds'", "'participants'")
        # Add organizationId to message writes if missing
        if "'organizationId'" not in content.split("sendMessage")[1][:500] if "sendMessage" in content else True:
            old_set = "'senderId': senderId,"
            new_set = "'senderId': senderId,\n      'organizationId': organizationId,"
            if old_set in content:
                content = content.replace(old_set, new_set, 1)
        msg_repo.write_text(content, encoding="utf-8")
        print(f"  [OK] messaging_repository.dart: fixed ({count} field rename(s) + orgId)")
print()

# ============================================================================
# Rules fixes: users create (add 'owner'), notifications delete, messages
# ============================================================================
print("=" * 70); print("Rules fixes"); print("=" * 70); print()

rules_path = Path("firestore.rules")
rules_content = rules_path.read_text(encoding="utf-8")

# Fix 1: Add 'owner' to users create allowed roles
old_users_create = "request.resource.data.role in ['student', 'parent', 'teacher'] &&"
new_users_create = "request.resource.data.role in ['student', 'parent', 'teacher', 'owner'] &&"

if old_users_create in rules_content:
    rules_content = rules_content.replace(old_users_create, new_users_create)
    print("  [OK] Rules: added 'owner' to users create allowed roles")
    fixes.append("Rules: owner create")

# Fix 2: Allow notification self-delete
old_notif_delete = "allow delete: if false;\n    }\n\n    // ====== Conversations"
new_notif_delete = "allow delete: if isAuth() && isInSameOrg() &&\n      resource.data.userId == request.auth.uid;\n    }\n\n    // ====== Conversations"

if old_notif_delete in rules_content:
    rules_content = rules_content.replace(old_notif_delete, new_notif_delete)
    print("  [OK] Rules: notifications delete allows self-delete")
    fixes.append("Rules: notification delete")

# Fix 3: Fix conversations — participants → participantIds (if rules use 'participants' and code uses 'participantIds')
# We renamed code to 'participants' above, so rules should now match. Verify.
if "resource.data.participants.hasAny" in rules_content:
    print("  [OK] Rules: conversations already uses 'participants' (matches code fix)")
elif "resource.data.participantIds.hasAny" in rules_content:
    # Rules use participantIds but we renamed code to participants — rename rules too
    rules_content = rules_content.replace("participantIds", "participants")
    print("  [OK] Rules: renamed participantIds → participants to match code")
    fixes.append("Rules: conversations field name")

# Fix 4: Messages — add organizationId requirement is already in isInSameOrg()
# The code now writes organizationId, so isInSameOrg() will pass
print("  [OK] Rules: messages will now pass (code writes organizationId)")

rules_path.write_text(rules_content, encoding="utf-8")
print()

# ============================================================================
# Summary + Build + Commit
# ============================================================================
print("=" * 70); print("SUMMARY"); print("=" * 70)
print(f"\nFixes applied: {len(fixes)}")
for f in fixes: print(f"  ✅ {f}")
print()
print("Files created:")
print("  - functions/src/functions/registerOwner.ts")
print("  - functions/src/functions/registerParent.ts")
print("Files modified:")
print("  - functions/src/index.ts (exports)")
print("  - lib/core/services/messaging_service.dart (participants + orgId + fullName)")
print("  - firestore.rules (owner create, notification delete, conversations field)")
print()

if not args.no_build:
    print("=" * 70); print("Building functions"); print("=" * 70)
    os.chdir("functions")
    try:
        r = subprocess.run(["npm","run","build"],shell=True)
        if r.returncode != 0: print("\n[WARNING] Build failed")
        else: print("\n  [OK] Build succeeded")
    finally: os.chdir("..")
    print()

print("=" * 70); print("Committing"); print("=" * 70)
msg = """fix(day3): registration CFs + messaging + rules

P0-1: Created registerOwner Cloud Function
  - Creates Auth account + organization + user doc + claims atomically
  - Rollback on failure (deletes Auth + org if user doc fails)
  - Replaces broken client-side registerOwner (rules blocked role:'owner')

P0-2: Created registerParent Cloud Function
  - Creates Auth account + user doc with organizationId:'' (not null)
  - Optional studentCode links parent to student immediately
  - Sets custom claims

P0-5: Fixed messaging
  - Renamed participantIds → participants in code (to match rules)
  - Added organizationId to message writes
  - Fixed sender name field (name → fullName)

Rules fixes:
  - users create: added 'owner' to allowed roles (backup for CF)
  - notifications delete: allows self-delete (was if false)
  - conversations: field name aligned with code

Manual work needed:
  - Update auth_service.dart registerOwner to call the new CF
  - Update auth_service.dart registerParent to call the new CF
  - Update auth_service.dart registerTeacherWithInvite to call redeemInviteCode CF
  - Test: owner registration, parent registration, messaging end-to-end

Verified against commit dbeacd7."""

subprocess.run(["git","add","-A"],check=True)
r = subprocess.run(["git","commit","-m",msg],capture_output=True,text=True)
if r.returncode != 0: print(f"[ERROR] {r.stderr}"); sys.exit(1)
new_commit = subprocess.check_output(["git","rev-parse","--short","HEAD"],text=True).strip()
print(f"\n  [OK] Commit: {new_commit}\n")

if args.no_push: print("[!] Skipping push"); sys.exit(0)
resp = input("Push to origin? (y/n): ").strip().lower()
if resp == "y":
    r = subprocess.run(["git","push","origin","main"])
    if r.returncode != 0: print("\n[ERROR] Push failed"); sys.exit(1)
    print(f"\n  [OK] Pushed: https://github.com/Strike87/Klasivo/commit/{new_commit}")
else: print("[!] Skipped")

print(f"\nRollback: git reset --hard {backup}")
